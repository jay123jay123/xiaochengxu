module.exports = {
    baseDomain: '127.0.0.1:3000',
};
