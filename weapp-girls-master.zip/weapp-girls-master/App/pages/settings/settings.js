//index.js
var app = getApp()
Page({
  data: {
    githubLink: 'https://github.com/litt1e-p',
    avatarLink: 'https://avatars2.githubusercontent.com/u/10734995?v=3&s=466'
  },
  onLoad: function () {
    // console.log('onLoad')
  }
})
