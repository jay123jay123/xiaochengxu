# WeChatMeiZhi

微信小程序版妹纸图 API from [干货集中营](http://gank.io)

本人是一枚即将毕业的Android开发工程师，初试前端。
便花了点时间查看微信小程序官方文档，以及各种demo，写成这个简单小程序。

感谢gank.io的API，感谢开源世界！


![image](https://github.com/brucevanfdm/WeChatMeiZhi/raw/master/screenshots/meizhi.gif)
